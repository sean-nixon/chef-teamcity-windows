<!-- This is a generated file. Please do not edit directly -->

# Maintainers

This file lists how this cookbook project is maintained. When making changes to the system, this file tells you who needs to review your patch - you need a review from an existing maintainer for the cookbook to provide a :+1: on your pull request. Additionally, you need to not receive a veto from a Lieutenant or the Project Lead.

Check out [How Cookbooks are Maintained](https://github.com/chef-cookbooks/community_cookbook_documentation/blob/master/CONTRIBUTING.MD) for details on the process and how to become a maintainer or the project lead.

# Project Maintainer
* [Adam Edwards](https://github.com/adamedx)

# Maintainers
* [Adam Edwards](https://github.com/adamedx)
* [Kartik Null Cating-Subramanian](https://github.com/ksubrama)
* [Steven Murawski](https://github.com/smurawski)
* [Matt Wrock](https://github.com/mwrock)
* [Jay Mundrawala](https://github.com/jaym)
* [Claire McQuin](https://github.com/mcquin)
* [Salim Alam](https://github.com/chefsalim)
* [Tim Smith](https://github.com/tas50)
* [Jennifer Davis](https://github.com/sigje)
