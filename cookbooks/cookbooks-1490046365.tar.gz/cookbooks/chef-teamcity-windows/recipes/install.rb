#
# Cookbook:: chef-teamcity-windows
# Recipe:: install
#
# Copyright:: 2017, The Authors, All Rights Reserved.

# Shorten hashes
$teamcity = node[:teamcity_windows][:debug]
$debug = teamcity[:debug]

# Set logging level to debug
Chef::Log.level = :debug if $debug

# Install Java 8 JDK
include_recipe 'java::default'

#tar_package "#{teamcity[:url]}" do
#  prefix '/usr/local'
#  creates '/usr/local/bin/pgpool'
#end
